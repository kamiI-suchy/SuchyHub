/*  bitbang_cbus.c – zmodyfikowany na potrzeby Zadania 24

    Sterowanie 4 LEDami przez CBUS bitbang z klawiatury:
      Klawisze 1,2,3,4  – włączają odpowiedni LED
      Klawisze q,w,e,r  – wyłączają odpowiedni LED
      ESC / x           – wyjście z programu

    CBUS bitmask:
      Górny nibble (bity 7-4): Input/Output  (1 = Output)
      Dolny nibble (bity 3-0): Output state  (1 = HI, LED ON)

    Oryginał: przykład bitbang_cbus.c z libftdi1-1.5
    Modyfikacja: sterowanie LED z klawiatury zamiast maski hex.
*/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <ftdi.h>

static struct termios orig_termios;

static void disable_raw_mode(void)
{
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &orig_termios);
}

static void enable_raw_mode(void)
{
    tcgetattr(STDIN_FILENO, &orig_termios);
    atexit(disable_raw_mode);
    struct termios raw = orig_termios;
    raw.c_lflag &= ~(ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
}

static void print_leds(unsigned char state)
{
    printf("\rLEDy: ");
    for (int i = 3; i >= 0; i--)
        printf("[LED%d:%s] ", i + 1, (state >> i) & 1 ? "ON " : "OFF");
    fflush(stdout);
}

int main(void)
{
    struct ftdi_context *ftdi;
    int f;
    unsigned char state = 0x00;  /* wszystkie LEDy zgaszone */

    if ((ftdi = ftdi_new()) == 0)
    {
        fprintf(stderr, "ftdi_new failed\n");
        return EXIT_FAILURE;
    }

    f = ftdi_usb_open(ftdi, 0x0403, 0x6001);
    if (f < 0 && f != -5)
    {
        fprintf(stderr, "unable to open ftdi device: %d (%s)\n",
                f, ftdi_get_error_string(ftdi));
        ftdi_free(ftdi);
        exit(-1);
    }
    printf("ftdi open succeeded: %d\n", f);

    /* Wszystkie 4 piny CBUS jako wyjścia, LEDy zgaszone */
    f = ftdi_set_bitmode(ftdi, 0xF0 | state, BITMODE_CBUS);
    if (f < 0)
    {
        fprintf(stderr, "set_bitmode failed, error %d (%s)\n",
                f, ftdi_get_error_string(ftdi));
        ftdi_usb_close(ftdi);
        ftdi_free(ftdi);
        exit(-1);
    }

    printf("\nSterowanie LEDami:\n");
    printf("  1 2 3 4  – włącz LED\n");
    printf("  q w e r  – wyłącz LED\n");
    printf("  ESC / x  – wyjście\n\n");
    print_leds(state);

    enable_raw_mode();

    while (1)
    {
        char c;
        if (read(STDIN_FILENO, &c, 1) != 1) break;

        unsigned char prev = state;

        switch (c)
        {
        case '1': state |=  0x01; break;   /* LED1 ON  – CBUS bit 0 */
        case '2': state |=  0x02; break;   /* LED2 ON  – CBUS bit 1 */
        case '3': state |=  0x04; break;   /* LED3 ON  – CBUS bit 2 */
        case '4': state |=  0x08; break;   /* LED4 ON  – CBUS bit 3 */
        case 'q': state &= ~0x01; break;   /* LED1 OFF */
        case 'w': state &= ~0x02; break;   /* LED2 OFF */
        case 'e': state &= ~0x04; break;   /* LED3 OFF */
        case 'r': state &= ~0x08; break;   /* LED4 OFF */
        case 27:                            /* ESC */
        case 'x': disable_raw_mode();
                  printf("\nKoniec.\n");
                  goto cleanup;
        default:  break;                    /* ignoruj inne klawisze */
        }

        if (state != prev)
        {
            unsigned char mask = 0xF0 | state;
            f = ftdi_set_bitmode(ftdi, mask, BITMODE_CBUS);
            if (f < 0)
            {
                fprintf(stderr, "\nset_bitmode failed, error %d (%s)\n",
                        f, ftdi_get_error_string(ftdi));
                disable_raw_mode();
                goto cleanup;
            }
            print_leds(state);
        }
    }

    disable_raw_mode();
cleanup:
    printf("\ndisabling bitbang mode\n");
    ftdi_disable_bitbang(ftdi);
    ftdi_usb_close(ftdi);
    ftdi_free(ftdi);

    return 0;
}